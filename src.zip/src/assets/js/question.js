$(document).ready(function(){
  $("#question").click(function(){
    $("#panel-1").slideToggle("fast");
  });
});