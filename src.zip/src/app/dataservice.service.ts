import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
@Injectable({
  providedIn: 'root'
})
export class DataService {
	constructor(private httpclient : HttpClient) {}
	 getusers(): Users{
		 return this.httpclient.get("https://reqres.in/api/users?page=2")
	 }
}
