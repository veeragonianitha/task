export class User{
	id:number;
	firstname:string;
	lastname:string;
	email:string;
	monthly advertising budget: number;
	phone number:number;
}